<?php

namespace Home\Model;
/**
 * ============================================================================
 * NiaoCMS商城
 * 官网地址:http://www.niaocms.com
 * 联系QQ:1692136178
 * ============================================================================
 * 交易数据
 */
class TradeStatistics extends BaseModel{
    //【待定】
    public function getOrderStatistics($parameter){

    }
}
