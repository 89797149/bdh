<?php

namespace Home\Action;


use Think\Action;

/**
 * 微信支付 PS:该文件在服务存在一个修改之前的副本
 */
class FooAction extends BaseAction {

    public function test(){
        echo 'aaaaaa';
        die;
    }
}
