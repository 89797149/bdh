<?php
return array(
	//'配置项'=>'配置值'
	//'URL_MODEL' => '2',
	'LOAD_EXT_CONFIG' => 'niao_cache_config',
);