<?php
return array(
	"app_shops_cache_time" => 5,//每个区的店铺缓存时间S 
	"app_indexType_Goods_cache_time" => 5,//分类下的精品推荐的商品数据缓存
	"niao_app_getShopIdInformation_cache_time" => 5,//店铺信息缓存
	"niao_app_getShopAllGoods_cache_time" => 5,//当前店铺所有商品缓存
	"niao_app_getShopIdType_cache_time" => 5,//当前店铺分类缓存
	"niao_app_getShopTypeGoods_cache_time" => 5,//当前店铺某个分类下的商品缓存
	"niao_app_getGoodDetails_cache_time" => 5,//单个商品信息缓存
	"niao_app_getGoodsIdShopDat_cache_time" => 5,//单个商品信息缓存
	"niao_app_getGoodphotoAlbum_cache_time" => 5,//缓存商品相册
	"niao_app_getGoodEvaluate_cache_time" => 5,//缓存商品评价
	"niao_app_getGoodIntroduce_cache_time" => 5,//缓存商品介绍
	"niao_app_typeTwoGoods_cache_time" => 5,//缓存商品介绍
	"niao_app_ShopTypeOneGoods_cache_time" => 5,//缓存商品介绍
	"allApiCacheTime" => 5
);