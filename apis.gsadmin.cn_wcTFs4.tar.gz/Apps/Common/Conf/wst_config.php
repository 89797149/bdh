<?php
 return array(
	    'WST_VERSION' => '3.0',
	    'WST_MD5' => 'c33dbd46422bef9e1c8e06e5ce1f6c36',
        'WST_M_IMG_SUFFIX'   => '',
	    'WST_RUNTIME_PATH'=>dirname(dirname(dirname(__File__)))."/Runtime",
        'DEFAULT_FILTER'=>'trim,htmlspecialchars',
        'WST_FEEDBACK'=>'http://www.niaocms.com/message/index.html',
        'WST_WEB'=>'http://www.niaocms.com',
 		'WST_UPLOAD_DIR'=>'adspic,brands,friendlinks,shops,staffs,users,mall,goods,complains,temp,uploads,GoodsCats,mobileUP,menus,newsImg',//规定合法目录
        'JXC_WEB'=>'http://www.jxcniaocms.cn',//进销存
	);
?>